package com.example.demo.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.CompanyDetails;
import com.example.demo.Entity.User;
import com.example.demo.Repository.CompanyDetailsRepository;
import com.example.demo.Repository.UserRepository;

@Service
public class AdminService{

	//User
	@Autowired
	private UserRepository userRepository;

	//Company
	@Autowired
	private CompanyDetailsRepository  companyRepository;


	/**
	 * User methods
	 */

	public List<User> getAllUsers()
	{
		List<User> users=new ArrayList<>();
		userRepository.findAll()
		.forEach(users::add);
		return users;
	}

	public User addUser(User user)

	{
		return userRepository.save(user);
	}
	public void UpdateUser(String id, User user) {
		userRepository.save(user);

	}
	public void deleteUser(String id) {
		userRepository.deleteById(id);

	}
	
	 /**
     * COMPANY methods
     */
	
	public List<CompanyDetails> getAllCompany()
	{
		List<CompanyDetails> companies=new ArrayList<>();
		companyRepository.findAll()
		.forEach(companies::add);
		return companies;
	}

	public void createCompany(CompanyDetails company)

	{
		companyRepository.save(company);
	}
	
	public void UpdateCompany(String id, CompanyDetails company) {
		companyRepository.save(company);

	}
	
	public void deleteCompany(String id) {
		companyRepository.deleteById(id);

	}



}


