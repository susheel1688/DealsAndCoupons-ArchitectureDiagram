package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.Entity.User;
import com.example.demo.Repository.UserRepository;
import com.example.demo.Service.AdminService;



@RunWith(SpringRunner.class)
@SpringBootTest
public class AdminServiceApplicationTests {


	@Autowired
	private AdminService adminService;

	@MockBean
	private UserRepository userRepository;


	//TEST GET USER
	
	@Test
	public void getUsersTest() {
		when(userRepository.findAll()).thenReturn(Stream.of(new User("Danile","123@","USA"), new User("Bob","789@","emma@123")).collect(Collectors.toList()));
		assertEquals(2, adminService.getAllUsers().size());
	}

	//TEST ADD USER
	
	@Test
	public void addUserTest() {
		User user = new User("Harry","678@pass","Harry@gmail.com");
		when(userRepository.save(user)).thenReturn(user);
		assertThat(user).isEqualTo(adminService.addUser(user));
		
	}
	
	//TEST DELETE BY USER ID
	
	@Test
	public void deleteUserTest() {
		
		String id="123456";
		adminService.deleteUser(id);
		verify(userRepository, times(1)).deleteById(id);
	
}
}



